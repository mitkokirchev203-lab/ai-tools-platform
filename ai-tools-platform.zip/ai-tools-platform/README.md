# 🚀 AI Tools Sharing Platform
Full-stack приложение (Laravel + Next.js + Docker) за вътрешно споделяне на AI инструменти.
