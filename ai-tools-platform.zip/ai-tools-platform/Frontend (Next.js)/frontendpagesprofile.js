export default function Profile() {
  return (
    <div className="p-6">
      <h2 className="text-2xl font-semibold">Профил</h2>
      <p>Име: Иван Иванов</p>
      <p>Роля: Owner</p>
    </div>
  )
}
